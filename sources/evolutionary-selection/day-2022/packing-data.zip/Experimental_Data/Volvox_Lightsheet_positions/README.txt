Thomas Day
Last Modified: 2021_05_27
Each file contains the xyz coordinates of somatic cells distributed on the surface of a Volvox carteri organism. Each file corresponds to a different Volvox organism. The format is as follows:
1st column: X coordinate
2nd column: Y coordinate
3rd column: Z coordinate