Thomas Day
Last modified: 2021_05_27
Each file contains the xyz coordinates of the centers of each cell in a snowflake yeast cluster. Each file corresponds to one cluster. The format is as follows:
1st column: a number indexing the cells
2nd column: X coordinate
3rd column: Y coordinate
4th column: Z coordinate