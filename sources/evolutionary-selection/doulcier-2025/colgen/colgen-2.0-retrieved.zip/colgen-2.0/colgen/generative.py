"""Generative - Generate random trees
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU GPL3+
"""
import logging
from itertools import chain
import numpy as np
import pandas as pd

def generate_random_one_mutation(s1=0.5,s2=0.99,N=40,T=10,tmut=None):
    """Generate a fake tree with N collectives over T generations.

    The initial survival probability of collectives is s1.

    The survival probability of a collective is the same as its parent. Except for
    one collective at generation tmut that will mutate to survival s2.
    """
    if tmut is None:
        tmut = T//3

    collectives = []
    collectives.append([dict(name="C{}_T00".format(n),
                             parent='ROOT',
                             time=0,
                             trait=s1)
                        for n in range(N)])
    for t in range(1,T):

        for n in range(N):
            collectives[-1][n]['survived'] = np.random.random()<collectives[-1][n]['trait']

        survivors = [c for c in collectives[-1] if c['survived']]
        if len(survivors)==0:
            raise ValueError("Population Extinct")
        parents = [c if c['survived'] else np.random.choice(survivors)
                   for c in collectives[-1]]

        collectives.append([])
        for n, parent in zip(range(N), parents):
            trait = parent['trait']
            collectives[-1].append(dict(
                name="C{}_T{:02}".format(n,t),
                parent= parent['name'],
                time=t,
                trait=parent['trait']))
        if t==tmut:
            mutated = np.random.choice(range(N))
            collectives[-1][mutated]['trait'] = s2
            collectives[-1][mutated]['mutated'] = True

    for n in range(N):
        collectives[-1][n]['survived'] = np.random.random()<collectives[-1][n]['trait']

    return pd.DataFrame(chain(*collectives)).fillna({"mutated":False})
