"""Data import
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU GPL3+
"""
import json
import logging

import pandas as pd
import numpy as np

import colgen.tree
logger = logging.getLogger('colgen')

def prepare_node_table(table):
    """ Prepare the data, set the elimination order, add the root in the list of nodes if absent"""
    if isinstance(table, str):
        logger.info('Reading {}'.format(table))
        table = pd.read_csv(table)
    else:
        table = table.copy()

    table = table.copy()
    all_nodes = frozenset(table.name.unique()).union(frozenset(table.parent.unique()))
    roots = frozenset(table.parent.unique()) - frozenset(table.name.unique())
    root_table = pd.DataFrame([{'name':n, 'parent':np.nan} for n in roots])
    root = list(roots)[0] if len(roots)==1 else None
    table = pd.concat([table,root_table])
    data = table_to_json(table, f"Tree_{root}", root=root, dump=False)
    colgen.tree.set_elimination_order(data)
    odict = {node:order-1 for order, node in colgen.tree.get_attr(data, 'name').items()}
    table['order'] = [odict[n] for n in table.name]
    table.sort_values(by="order", ascending=True, inplace=True)
    table.reset_index(drop=True, inplace=True)
    return table 

def table_to_json(table, name=None, root=None, dump=True):
    """ Build a json tree from a pandas dataframe.

    Arguments:
    table (pandas dataframe): tree data, with `parent` and `name` columns.
    name (str): name of the tree
    root (str): name of the root name, else will look for one containing 'ROOT'.
    dump (bool): if true return the json dumps (str) else return a dict.
    """
    if root is None:
        nodes = table.parent.unique()
        if 'ROOT' in nodes:
            root = 'ROOT'
        else:
            for i in nodes:
                if "ROOT" in i:
                    root = i
    if root is None:
        logger.warning(f'No root in tree {name}')
        return {}
    if 'time' in table.columns:
        table.sort_values('time', ascending=False, inplace=True)

    tree = {'children':build_tree(table.fillna('nan'),
                                  root,
                                  0),
            'name': root,
            'tree_name':name}
    if dump:
        return json.dumps(tree)
    return tree

def build_tree(data, tube, time, ancestor=None):
    '''Recursively find all children node and build a dictionnary tree to be used with d3'''
    out = [row.to_dict()
           for _, row
           in data.loc[data.parent == tube, :].iterrows()]
    for child in out:
        child["children"] = build_tree(data, child['name'], time+1, ancestor)
    return out
