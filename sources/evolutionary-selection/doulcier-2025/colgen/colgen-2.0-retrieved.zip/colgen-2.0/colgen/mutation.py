"""mutation.py - A mutation mapping method by BN,
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU AGPL3+
"""
import logging
from functools import partial
import json

import numpy as np 
import pandas as pd

import colgen.tree as tree
import colgen.dataimport
from colgen.bn_discrete import max_product_variable_elimination, Potential

logger = logging.getLogger('colgen.mutation')

def fit(node_table, mutation_table, mu, mu_r, p0, p1):
    """Fit the mutation propagation model.

    Args:
    - node_table (pd.dataframe): A table containing the genealogy
      with columns `name` and `parent`, potentially a column `sequenced`.
    - mutation_table (pd.dataframe): A table with the sequenced mutations,
      with columns `mutation` and `node`.
    - mu (float): Probability of mutation
    - mu_r (float): Probability of reversion
    - p0 (float): Probability of detecting a mutation if it is not present.
    - p1 (float): Probability of detecting a mutation if it is present.

    Returns: 
    - Report (pd.dataframe): One line per mutation. 
    - Wide_table (pd.dataframe): One line per node, one column per mutation. 
    """
    
    # Load the tree, set elimination order...
    data = load_tree(node_table, mutation_table)
    
    # Set the emission-transmission model parameters 
    proba = partial(probability, mu=float(mu), mu_r=float(mu_r), p0=float(p0), p1=float(p1))
    
    # Parsing identical patterns of mutation
    patterns, descriptions = detect_patterns(mutation_table)
    logger.info(f"Detected {patterns.pattern.nunique()} unique patterns")
    
    # Use the Max-Product-Variable eliminatio procedure for each mutation pattern 
    report = []
    long_table = []
    for pat, nodes in patterns.groupby('pattern'):
        logger.info(f"Pattern {pat}...")
        bear_it = set(nodes.node)
        factors = generate_mut_factor(data, bear_it, proba)
        config, ret, _ = max_product_variable_elimination(factors,
                                                          data.loc[:,'order'].to_list(),
                                                          backtrack=True)
        lglikelihood = ret[0].value
        # Output
        report.append({
            'pattern': pat,
            'number': int(np.sum(list(config.values()))),
            'number_seq':len(bear_it),
            'confidence':np.exp(lglikelihood),
            'mu':mu,
            'mu_reverse':mu_r,
            'p0':p0,
            'p1':p1,
            'nodes': json.dumps([n for n, i in zip(data.loc[:,'name'],
                                                   data.loc[:,'order']) if config[i]])
        })
        for n, i in zip(data.name, data.order):
            long_table.append({"node":n, "pattern":pat, "present":config[i]})

    # Export output
    long_table = pd.DataFrame(long_table)
    long_table = pd.merge(long_table, descriptions, left_on="pattern", right_on="pattern")
    wide_table = long_table.pivot(index='node', columns='mutation',
                                  values='present').fillna(0).reset_index()
    wide_table = pd.merge(wide_table, data, left_on='node', right_on='name')
    wide_table.drop(columns=["order","node"], inplace=True)
    
    report = pd.DataFrame(report)
    report = pd.merge(report, descriptions, left_on="pattern",right_on="pattern")
    return report, wide_table

def probability(focal, parent,  mu, mu_r, p0, p1):
    """ The probability that the focal node bear the trait, conditional on
        the fact that the parent bears it

    Args:
        - focal (bool): True if the mutation is present in the focal node
        - parent (bool): True if the mutation is present in the parent node
        - mu (float): Probability of mutation
        - mu_r (float): Probability of reversion
        - p0 (float): Probability of detecting a mutation if it is not present.
        - p1 (float): Probability of detecting a mutation if it is present.

    Return: P(X_i = k | X_pa(i) = j) P(E_i=e_i | X_i=k)
    """
    p_mut = { (True, False): mu, # Mutation
              (False, True): mu_r, # Reversion
              (False, False): 1-mu, # No mutation
              (True, True): 1-mu_r # No reversion
             }[focal, parent] #P(X_i| X_pa(i))
    p_emission = p1 if focal else 1-p0 # P(E=1 | X = 1)
    return np.log(p_emission*p_mut)

def load_tree(node_table, mutation_table):
    """ Prepare the data, set the elimination order, the sequenced column"""
    # Compute the elimination order on the tree deal with the root.
    table = colgen.dataimport.prepare_node_table(node_table)
    all_nodes = frozenset(table.name.unique())
    
    # Establish which nodes where sequenced and which nodes are not.
    if "sequenced" not in table.columns:
        logger.warning('No column "sequenced", assuming that collectives in the mutation list were sequenced')
        sequenced = frozenset(mutation_table.node.unique()).intersection(all_nodes)
        weird = frozenset(mutation_table.node.unique()) - all_nodes
        if len(weird):
            logger.warning(f"The following nodes are in the mutation table but not in the genealogy: {weird}")
            raise ValueError(f"Sequenced Nodes Missing in genealogy: {weird}")
        table['sequenced'] = [x in sequenced for x in table.name]
    logger.info('{} mutations / {}/{} nodes sequenced'.format(mutation_table.mutation.nunique(),
                                                              len(sequenced), len(all_nodes)))
    return table

def detect_patterns(table):
    """Group the mutations in the table in "patterns" of node. Two
    mutations belong to the same pattern if they are present in
    exactly the same nodes.

    Args:
    - table (pd.dataframe): A table with columns `mutation` and `node`.

    Return:
    - patterns (pd.Dataframe): A table with columns `pattern` and `node`, without the duplicated information that can be used for the inference.
    - descriptions (pd.Dataframe): A table per mutation, with the pattern they belong to. 
    """
    
    table = table.copy()
    nodes = table.node.unique()
    table['sequenced'] = 1
    pivot = table.pivot(index="mutation", columns="node", values='sequenced').fillna(0)
    unique = pivot.reset_index(drop=True).drop_duplicates()
    unique['pattern'] = [f"PATTERN_{i+1}" for i in range(unique.shape[0])]
    descriptions = pd.merge(unique, pivot.reset_index(),
                            how='right').loc[:,["pattern","mutation"]].reset_index(drop=True)
    descriptions.columns = descriptions.columns.set_names([None])
    patterns = unique.melt(id_vars="pattern", value_vars=nodes)
    patterns = patterns[patterns.value!=0].reset_index(drop=True).drop(columns='value')
    return patterns, descriptions 
    
def generate_mut_factor(data, bear_it, probability):
    """Generate the list of factor that correspond to mutations beared
    by the nodes in bear_it

    Arguments:
    data (pd.Dataframe) a table with columns name, parent, sequenced, order.
    bear_it (set): a set of node bearing the mutation
    probability (function): a function a,b -> P(X=a|X_p=b)
    """
    factors = []
    order = data.set_index("name").order.to_dict()

    domain = {}
    for name,node in data.set_index('name').iterrows():
        if node.sequenced:
            if name in bear_it:
                domain[node.order] = [1]
            else:
                domain[node.order] = [0]
        else:
            domain[node.order] = [0,1]
            
    for name, node in data.set_index('name').sort_values("order", ascending=True).iterrows():
        if not pd.isna(node.parent):
            factors.append(Potential([node.order, order[node.parent]],
                                     probability,
                                     name=f'Potential of {name}',
                                     domain_var=domain))
        else:
            factors.append(Potential([node.order],
                                     lambda x: 0, #(log(P(X)) = log(1)= 0 
                                     name=f'Potential of {name}',
                                     domain_var=domain))
    return factors
