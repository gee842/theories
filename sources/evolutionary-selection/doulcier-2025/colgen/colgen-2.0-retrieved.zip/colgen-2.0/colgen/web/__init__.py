"""web interface
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU GPL3+
"""

import logging
import os
import shutil
import webbrowser
import socket
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from collections import defaultdict

import pandas as pd

from colgen import APP_PATH
import colgen.dataimport

logger = logging.getLogger('colgen.web')

def main(files, path, port, browser, theme, mutation_suffix, static_link, batch):
    """Interactive visualisation"""
    # Load the datasets
    data = load_data(files, mutation_suffix)
    # Export the data
    export(data, theme, path, static_link)

    if not batch:
        # Start the web server.
        start_server(path,
                     port=int(port),
                     open_webbrowser=browser)

def export(data, theme, path, static_link=False):
    """Export the interactive visualization in the path"""
    # Create the directory
    for d in ["tree", "table", "mutations"]:
        os.makedirs(os.path.join(path, d), exist_ok=True)

    # Link or export the static files
    static_path = os.path.join(APP_PATH, 'web', 'static')
    if not os.path.exists(os.path.join(path,'static')):
        if static_link:
            os.symlink(static_path, os.path.join(path,'static'))
        else:
            shutil.copytree(static_path, os.path.join(path,'static'))

    # Export the index
    with open(os.path.join(APP_PATH, 'web', 'template', 'index.html'),'r') as file:
        index = file.read().format(THEME=theme)
    with open(os.path.join(path, 'index.html'),'w') as file:
        file.write(index)

    # Export the data
    with open(os.path.join(path, 'dataset_list'), 'w') as file:
        file.write(json.dumps({'tree_and_data':[x for x in sorted(data.keys())]}))
    for name, dt in data.items():
        with open(os.path.join(path, 'tree', name),'w') as file:
            file.write(dt['tree'])
        dt['data'].sort_values(by='name').to_csv(os.path.join(path, 'table', name),
                                                 index=False)
        if 'mutations' in dt:
            dt['mutations'].to_csv(os.path.join(path, 'mutations', name),
                                   index=False)
        else:
            pd.DataFrame([]).to_csv(os.path.join(path, 'mutations', name),
                                    index=False)

def load_data(path, mutation_suffix):
    """Load all the datasets in path"""
    data = {}
    for fi in path:
        bname = os.path.basename(fi).replace('.csv','')
        df = pd.read_csv(fi)
        if 'parent' in df.columns:
            nodes = df.parent.unique()
            root = None
            if 'ROOT' in nodes:
                root = 'ROOT'
            else:
                for i in nodes:
                    if "ROOT" in i:
                        root = i
            if root is not None:
                tree = colgen.dataimport.table_to_json(df,
                                                       name=bname,
                                                       root=root)
                data[bname] = dict(data=df, tree=tree)
            else:
                logger.warning('File {} ignored - no `ROOT` node'.format(bname))

        else:
            logger.warning('File {} ignored - no `parent` column'.format(bname))
        mutation_path = fi.replace('.csv', mutation_suffix+'.csv')
        if os.path.exists(mutation_path):
            df_mut = pd.read_csv(mutation_path)
            data[bname]['mutations'] = df_mut
    return data 

def start_server(path, port=None, open_webbrowser=False):
    """ Start the web server.

    Args:
        port: first port to try (will try port up to port+10).
        open_webbrowser (bool): if true try to open the webbrowser on the server.
    """

    ## Try to find an open port.
    port = int(port)
    iport = port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as skt:
        while not check_port(port, skt) and port < iport+10:
            port += 1
        if port >= iport+10:
            logger.critical('Failed to find an open port.')
            return False


    os.chdir(path)
    server_object = HTTPServer(server_address=('', port),
                               RequestHandlerClass =
                               SimpleHTTPRequestHandler,
                               )
    url = f'http://localhost:{port}'
    if open_webbrowser:
        browser = webbrowser.get('firefox')
        browser.open(url)
    logger.info(f"Serving the interactive visualisation on {url}")
    server_object.serve_forever()
    return port

def check_port(port, skt=None):
    """ Check if `port` is in use using the socket `skt`"""
    if skt is None:
        skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        skt.bind(("127.0.0.1", port))
    except OSError as ex:
        # On windows, a OSError "winerror 10048" is thrown if the
        # port is in use.
        logger.info("Port {} is already in use: {}".format(port, ex))
        return False
    except socket.error as ex:
        if ex.errno == 98:
            logger.info("Port {} is already in use".format(port))
            return False
        else:
            raise ex
    else:
        return True
