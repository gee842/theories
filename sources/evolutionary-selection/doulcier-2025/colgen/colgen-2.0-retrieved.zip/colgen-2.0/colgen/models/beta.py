""" Beta distribution model
This file is part of the colgen package.
Copyright 2020 Guilhem Doulcier, Licence GNU GPLv3+
"""
from functools import partial, lru_cache
import logging
import scipy.stats
import scipy.special
import scipy.integrate
import numpy as np

logger = logging.getLogger('colgen.models')

def integrate_beta(s, p, x,y):
    alpha = 1+p*s
    beta = 1+(1-p)*s
    rv = scipy.stats.beta(alpha,beta)
    with np.errstate(all='raise'):
         try:
             p1 = rv.logcdf(y)
             p0 = rv.logcdf(x)
             logproba = p1 + np.log(-np.expm1(p0 - p1))
         except FloatingPointError as ex:
             try:
                 logproba, err = np.log(scipy.integrate.quad(rv.pdf,x,y))
             except FloatingPointError as ex:
                 logproba = -np.inf
    return logproba

@lru_cache(maxsize=None)
def model(t, parent, is_extinct, sigma, grid):
    """Return log(P(X=t|X_p_i=parent)P(E=is_extinct|X=t))

    t: trait of the focal node
    parent: trait of the parental node
    is_extinct: true if the node is extinct
    sigma: confidence
    grid: domain size
    """
    if not sigma:
        return np.log(1/(2*grid**2))
    dx = 1/(2*grid)
    proba_trait_knowing_parent = integrate_beta(sigma,
                                                parent,
                                                t-dx,
                                                t+dx)
    prob_extinct_knowing_trait = 1-t if is_extinct else t
    if not prob_extinct_knowing_trait:
        return -np.inf
    return (proba_trait_knowing_parent
            +np.log(prob_extinct_knowing_trait)
            +np.log(2*dx))

def get_domain(steps):
    dx = 1/(steps*2)
    return np.linspace(0+dx, 1-dx, steps)


