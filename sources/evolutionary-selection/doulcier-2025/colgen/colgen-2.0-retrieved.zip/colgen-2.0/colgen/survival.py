"""survival.py - survival estimation
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU AGPL3+
"""
import os
from functools import partial
import logging

import numpy as np
import pandas as pd

import colgen.bn_discrete as bn
import colgen.dataimport
import colgen.tree

logger = logging.getLogger('colgen.survival')

def fit(csv, model,  sigma_range, max_em_steps=10, steps=8):
    """Run the survival estimation procedure

    Args:
       - csv (path or pd.dataframe): The genealogy, with columns `name`, `parent` and `extinct`
       - model (function): the propagation model
       - sigma_range (list): Initial, min and max values of the model parameter
       - max_em_steps (int): Maximum number of Expectation-Maximizations
       - step (int): number of discretisation elements

    Returns:
       - data (pd.DataFrame): the genealogy with "survival_estimate" and "survival_change" added.
       - convergence (pd.Dataframe): A line per E-M step with the sigma value and likelihood.
    """
    pot = model.model
    dom = model.get_domain(steps)
    tree  = load_tree(csv)

    fg = factor_generator_generator(tree, partial(pot, grid=steps), default_domain=dom)
    dv = {k:dom for k in tree['order']}

    #init = tree.set_index("order").loc[:,'prop_survived_children'].to_dict()
    #init = {k:np.random.random() for k in tree['order']}
    #mean = tree.extinct.mean()
    #init = {k:1-mean for k in tree['order']}
    init = None
    
    sigma_conv, lklhood_conv, map_config = bn.expectation_maximisation(
        factor_generator=fg,
        domain_var=dv,
        ordering=tree['order'].to_list(),
        theta=sigma_range[0],
        theta_min=sigma_range[1],
        theta_max=sigma_range[2],
        mxsteps=max_em_steps,
        init_config=init)

    tree['survival_estimate'] = [map_config[i] for i in tree.order]
    survival_estimate = tree.set_index('name').survival_estimate.to_dict()
    tree['survival_change'] = [s-survival_estimate[p]
                               if p in survival_estimate else 0
                               for s,p in zip(tree.survival_estimate, tree.parent)]

    convergence = pd.DataFrame({'likelihood':lklhood_conv, 'sigma':sigma_conv})
    return tree, convergence

def load_tree(file):
    """ Load the tree dataset, compute the elimination order, setup initial configuration,
    build the tree object."""
    dataframe = colgen.dataimport.prepare_node_table(file)
    dataframe.fillna({"extinct":0}, inplace=True)

    ndead = np.sum(dataframe.extinct)
    logger.debug("{}/{} ~ {:%} are extinct".format(ndead,
                                                   len(dataframe.extinct),
                                                   ndead/len(dataframe.extinct)))

    def prop_survived_children(name, df):
        clutch = df.query('parent=="{0}"|name=="{0}"'.format(name))
        return 1 - (clutch.extinct.sum() / clutch.shape[0])
    dataframe["prop_survived_children"] = [prop_survived_children(n, dataframe)
                                           for n in dataframe.name]

    return dataframe

def factor_generator_generator(data, potential, default_domain=None):
    def factor_generator(sigma_value, domain_var):
        factors = []
        order = data.set_index("name").order.to_dict()
        for name, node in data.set_index('name').sort_values("order", ascending=True).iterrows():
            if not pd.isna(node.parent):
                factors.append(
                    bn.Potential([node.order, order[node.parent]],
                                 lambda trait, parent, extinct=node.extinct, sigma=sigma_value: potential(
                                     trait, parent, extinct, sigma=sigma),
                                 name=f'Potential of {name}',
                                 default_domain=default_domain,
                                 domain_var=domain_var))
            else:
                dx = np.log(1/len(default_domain))
                factors.append(
                    bn.Potential([node.order],
                                 (lambda trait: (np.log(1-trait) if (1-trait) else -np.inf) + dx)
                                 if node.extinct
                                 else (lambda trait: (np.log(trait) if trait else -np.inf) + dx),
                                 name=f'Potential of {name}',
                                 default_domain=default_domain,
                                 domain_var=domain_var))
        return factors
    return factor_generator
