import numpy as np
import matplotlib.pyplot as plt 
from mpl_toolkits.axes_grid1 import make_axes_locatable

def plot(potential, ax=None, levels=None, continuous=True, text=False):
    """Draw potential value"""
    if ax is None:
        ax = plt.gca()
    fig = plt.gcf()
    if len(potential.scope) == 2:
        if continuous:
            img1 = ax.contourf(
                potential.domain_var[potential.scope[0]], potential.domain_var[potential.scope[1]], potential.value, levels=levels)
            ax.set(
                xlabel=potential.scope[0], ylabel=potential.scope[1], title='{}'.format(potential))

        else:
            img1 = ax.imshow(potential.value,
                             interpolation=None,
                             extent=[0,
                                     len(potential.domain_var[potential.scope[1]]),
                                     0,
                                     len(potential.domain_var[potential.scope[0]])],
                             origin='lower')
            ax.set(xticks=np.arange(len(potential.domain_var[potential.scope[1]]))+0.5,
                   xticklabels=potential.domain_var[potential.scope[1]],
                   yticks=np.arange(len(potential.domain_var[potential.scope[0]]))+0.5,
                   yticklabels=potential.domain_var[potential.scope[0]])
            ax.set(xlabel='X{} <{}>'.format(potential.scope[1], len(potential.domain_var[potential.scope[1]])),
                   ylabel='X{} <{}>'.format(potential.scope[0], len(
                       potential.domain_var[potential.scope[0]])),
                   title='{}'.format(potential))

        if text:
            for i, x in enumerate(np.arange(len(potential.domain_var[potential.scope[1]]))+0.5):
                for j, y in enumerate(np.arange(len(potential.domain_var[potential.scope[0]]))+0.5):
                    ax.text(
                        x, y, potential.value[j, i], horizontalalignment='center', verticalalignment='center')
        divider = make_axes_locatable(ax)
        cax1 = divider.append_axes("right", size="5%", pad=0.05)
        fig.colorbar(img1, cax=cax1)
    if len(potential.scope) == 1:
        if continuous:
            ax.plot(potential.domain_var[potential.scope[0]], potential.value)
        if not continuous:
            ax.bar(potential.domain_var[potential.scope[0]], potential.value)

        ax.set(xlabel=potential.scope[0],
               ylabel='Value', title='{}'.format(potential))
    return ax
