"""Colgen - Collective Genealogies Display and Analysis
This file is part of the colgen package.
Copyright 2019 Guilhem Doulcier, Licence GNU GPL3+
"""
import os

APP_PATH = os.path.dirname(os.path.abspath(__file__))
