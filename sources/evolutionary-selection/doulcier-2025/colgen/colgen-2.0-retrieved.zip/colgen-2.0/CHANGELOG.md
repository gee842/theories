#  Colgen Changelog

All notable changes to this project will be documented in this file.

## [2.0 branch]- 2024-05-10
- Changed the likelihood optimization procedure for E-M to a global one (scipy.optimize.shgo)
- Add a procedure to deduplicate mutations with the same evidence by computing patterns first
- Add CI that run the test suite 
- Merge the mutation code with the survival code
- Drop the cherrypy dependency
- Add the option to export a static version of the interactive output 
- Fix the survival of the ROOT problem

## [1.2] - 2021-06-29

- Added the `survival` interface.
- General code cleanup
- Improved the documentation of colgen.tree

## [1.1] - 2020-02-07

- Removed Cairo dependency
- Added a new plotting API using matplotlib
- Removed the plot CLI interface
- Added new survival models (beta, jump, truncnorm)
- Fix bugs

## [1.0] - 2019-12-02

- First version available on 10.5281/zenodo.7342768
