import logging
from itertools import chain
from functools import partial 
import numpy as np
import pandas as pd
import pytest

import colgen.generative
import colgen.survival
import colgen.models.jump

logging.getLogger('colgen')
logging.basicConfig(level=logging.DEBUG)


def test_fit():
    mock_data = pd.DataFrame([{'name':'C1','parent':'ROOT',  'extinct':0},
                              {'name':'C2','parent':'C1',  'extinct':1},
                              {'name':'C3','parent':'C1',  'extinct':1},
                              {'name':'C4','parent':'C3',  'extinct':1}])
    df, conv = colgen.survival.fit(mock_data, colgen.models.jump, (0.5,0,1))
    print(df)
    print(conv)
    assert 'survival_estimate' in df
    assert 'survival_change' in df
    assert 'name' in df
    assert 'parent' in df
    assert 'extinct' in df
    assert 'likelihood' in conv
    assert 'sigma' in conv
    assert conv.loc[0,'sigma'] == 0.5
    assert all(df.survival_estimate<=1)
    assert all(0<=df.survival_estimate)
    assert all(df.survival_change<1)
    assert all(-1<=df.survival_change)


def test_breakpoint():
    np.random.seed(126) # This seed gives a nice tree
    df = colgen.generative.generate_random_one_mutation(s1=.4, s2=.99, T=10, N=10)
    assert df['mutated'].sum()==1
    df['extinct'] = [not x for x in df['survived']]
    out, conv = colgen.survival.fit(df,
                                    colgen.models.jump,
                                    sigma_range=(0.5,0,1),
                                    steps=20,
                                    max_em_steps=10)
    print(out)
    print(out.groupby(["survival_estimate","mutated","trait"]).count().name)
    print("Mutated")
    m = out[out.mutated==1]
    print(m)

    print("Non Mutated")
    nm = out[out.mutated!=1]
    print(nm)
    assert m.survival_change.values[0] != 0, "Mutated node is 0"
    assert all(nm.survival_change.values == 0), "A non mutated node is not 0"


@pytest.mark.parametrize("grid", [10,15])
@pytest.mark.parametrize("model_pair", [(colgen.models.beta,10), (colgen.models.jump,0.6)])
def test_generate_factors(grid, model_pair):
    node_table = pd.DataFrame(
            dict(name=['ROOT','node1','node2'],
                 parent=[np.nan, 'ROOT','ROOT'],
                 order=[2,1,0],
                 extinct=[0,0,1]))
    model,sigma = model_pair
    d = model.get_domain(grid)
    p = partial(model.model, grid=grid)
    factors = colgen.survival.factor_generator_generator(node_table, 
                                                         p,
                                                         default_domain=d)(sigma,{0:d,1:d,2:d})
    for f in factors: 
        assert np.isclose(np.sum(np.exp(f.value)), 0.5)
