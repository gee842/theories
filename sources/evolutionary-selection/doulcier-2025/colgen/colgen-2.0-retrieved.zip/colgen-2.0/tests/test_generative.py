import colgen.generative
import numpy as np
import pandas as pd

def test_random_one():
    df = colgen.generative.generate_random_one_mutation(s1=.5, s2=1, T=10, N=10)
    assert df['mutated'].sum() == 1
    assert df.shape[0] == 100 
    assert df[df.time==10//3].trait.nunique()==2
