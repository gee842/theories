""" Test mutation propagation"""
from functools import partial 
import numpy as np
import pandas as pd
import colgen.mutation

def test_detect_patterns():
    mutations = {"mut1":["node1","node2","node3"],
                 "mut2":["node1","node2","node3"],
                 "mut3":["node1","node2"],
                 "mut4":["node1","node2","node3","node4"],
                 "mut5":["node4","node5"],
                 "mut6":["node1","node2"],}
    result_desc = {"mut1":"PATTERN_1", "mut2":"PATTERN_1",
                   "mut3":"PATTERN_2", "mut4":"PATTERN_3",
                   "mut5":"PATTERN_4", "mut6":"PATTERN_2"}
    result_pat = pd.DataFrame([dict(node='node1',pattern='PATTERN_1'),
                               dict(node='node1',pattern='PATTERN_2'),
                               dict(node='node1',pattern='PATTERN_3'),
                               dict(node='node2',pattern='PATTERN_1'),
                               dict(node='node2',pattern='PATTERN_2'),
                               dict(node='node2',pattern='PATTERN_3'),
                               dict(node='node3',pattern='PATTERN_1'),
                               dict(node='node3',pattern='PATTERN_3'),
                               dict(node='node4',pattern='PATTERN_3'),
                               dict(node='node4',pattern='PATTERN_4'),
                               dict(node='node5',pattern='PATTERN_4'),
                               ])
    result_pat = result_pat.loc[:, ['pattern','node']]
    fixture = []
    for mutation,v in mutations.items():
        for node in v:
            fixture.append({"node": node, "mutation":mutation})
    fixture = pd.DataFrame(fixture)

    print("INPUT")
    print(fixture.to_string())
    patterns, descriptions = colgen.mutation.detect_patterns(fixture)
    print("Check that the patterns are correct")
    print("EXPECTED")
    print(result_pat.to_string())
    print("OUTPUT")
    print("descriptions:")
    print(descriptions.to_string())
    print("patterns:")
    print(patterns.to_string())

    
    for k,v in descriptions.set_index('mutation').pattern.to_dict().items():
        print(f"{k} {v} should be {result_desc[k]}")
        assert v == result_desc[k]
    assert patterns.equals(result_pat)

def test_probability():
    p = colgen.mutation.probability
    
    mu = 0.1
    mu_r = 0.01

    assert p(focal=True, parent=False, mu=mu, mu_r=mu_r, p0=0, p1=1) == np.log(mu), "There is a mutation"
    assert p(focal=False, parent=True, mu=mu, mu_r=mu_r, p0=0, p1=1) == np.log(mu_r), "There is a reversion"

def test_generate_factors():
    mu = 0.1
    mu_r = 0.001
    p0 = 0.02
    p1 = .98
    p = partial(colgen.mutation.probability, mu=mu, mu_r=mu_r, p0=p0, p1=p1)
    node_table = pd.DataFrame(
        dict(name=['ROOT','node1','node2','node3'],
             parent=[np.nan,'ROOT','node1','node1'],
             order=[3,2,1,0],
             sequenced=[True,True,True,False],
             )).sort_values('order').reset_index(drop=True)

    print("NODE TABLE")
    print(node_table)

    factors = colgen.mutation.generate_mut_factor(node_table, {"node2",}, p)
    print("FACTORS FOR A MUTATION IN NODE2")

    expected = [{'scope':[0,2], 'value':np.array([[(1-mu)*(1-p0), mu*p1]]).transpose()},
                {'scope':[1,2], 'value':np.array([[mu*p1]])},
                {'scope':[2,3], 'value':np.array([[(1-mu)*(1-p0)]])},
                {'scope':[3], 'value':np.array([1])}] 
    
    assert len(factors) == len(expected), 'Not enough factors'
    for f,e in zip(factors, expected):
        print("EXPECTED:", e)
        print("FACTOR:", f)
        assert f.scope == e['scope']
        np.testing.assert_allclose(f.value, np.log(e['value']))

def test_load_sequenced_root():
    node_table = pd.DataFrame(
        dict(name=['node1','node2','node3'],
             parent=['ROOT','node1','node1']))
    mutation_table = pd.DataFrame(
        dict(node=["ROOT","node1","node2"],
             mutation=["mut1","mut2","mut3"]))
    print("NODE TABLE\n", node_table)
    print("MUTATION TABLE\n", mutation_table)
    expected = pd.DataFrame(
        dict(name=['ROOT','node1','node2','node3'],
             parent=[np.nan,'ROOT','node1','node1'],
             order=[3,2,1,0],
             sequenced=[True,True,True,False],
             )).sort_values('order').reset_index(drop=True)

    print("EXPECTED\n", expected)
    
    output = colgen.mutation.load_tree(node_table,mutation_table)
    print("OUTPUT\n", output)
    assert output.equals(expected)

def test_load_simple():
    node_table = pd.DataFrame(
        dict(name=['node1','node2','node3'],
             parent=['ROOT','node1','node1']))
    mutation_table = pd.DataFrame(
        dict(node=["node1","node2"],
             mutation=["mut2","mut3"]))
    print("NODE TABLE\n", node_table)
    print("MUTATION TABLE\n", mutation_table)
    expected = pd.DataFrame(
        dict(name=['ROOT','node1','node2','node3'],
             parent=[np.nan,'ROOT','node1','node1'],
             order=[3,2,1,0],
             sequenced=[False,True,True,False],
             )).sort_values('order').reset_index(drop=True)
    print("EXPECTED\n", expected)
    output = colgen.mutation.load_tree(node_table,mutation_table)
    print("OUTPUT\n", output)
    assert output.equals(expected)
    
def test_stable():
    """ A simple test of the mutation propagation (not exhaustive).
    Test that sequenced mutations are in the mapping."""
    nd = ['node1','node2','node3']
    node_table = pd.DataFrame({'name': nd,
                               'parent': ['ROOT','node1','node1']})
    mutation_table = pd.DataFrame({'node': ['node1','node2','node2','node2'],
                                   'mutation': ['mut1','mut2','mut3','mut1']}) 
    report, mapping = colgen.mutation.fit(node_table, mutation_table, 0.01, 1e-9, 0, 1.0)

    print("REPORT")
    print(report.to_string())

    print("MAPPING")
    print(mapping)

    expected_seq = pd.Series([False, True, True ,False],
                             index=["ROOT","node1","node2","node3"],
                             name = "sequenced")    
    assert all(mapping.set_index('name').sequenced == expected_seq)   
    mapping.set_index('name', inplace=True)
    assert mapping.loc['node1','mut1'] == 1
    assert mapping.loc['node2','mut2'] == 1
    assert mapping.loc['node2','mut3'] == 1
    assert mapping.loc['node2','mut1'] == 1


def test_propagate():
    node_table = pd.DataFrame({'name': ['node1','node2','node3'],
                               'parent': ['ROOT','node1','node1']})
    mutation_table = pd.DataFrame({'node': ['node2','node3','node3'],
                                   'mutation': ['mut1','mut1','mut2']}) 
    report, mapping = colgen.mutation.fit(node_table, mutation_table, 0.1, 1.e-9, 1e-9, 1-1e-9)

    print("REPORT")
    print(report.to_string())

    print("MAPPING")
    print(mapping)
    
    mapping.set_index('name', inplace=True)
    assert mapping.loc['node1','mut1'] == 1
    assert mapping.loc['node2','mut1'] == 1
    assert mapping.loc['node3','mut1'] == 1
    assert mapping.loc['ROOT','mut1'] == 1 
    
    assert mapping.loc['node1','mut2'] == 0
    assert mapping.loc['node2','mut2'] == 0
    assert mapping.loc['node3','mut2'] == 1
    assert mapping.loc['ROOT','mut2'] == 0

