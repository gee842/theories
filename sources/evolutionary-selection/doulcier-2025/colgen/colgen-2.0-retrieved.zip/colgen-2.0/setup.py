from setuptools import setup

setup(packages=['colgen', 'colgen.web', 'colgen.models'])
