Worlds we can inhabit / Edition 05
A worldbuilding project by Ren, developed with AI
7 September 2026

Extract this entire ZIP into one folder, then open START-HERE.html.
The PDF, HTML reader and Markdown reader can also be opened directly.
The HTML reader contains full copy, illustration descriptions and sources.
No installation or account is required. External sources require internet access.
The PDF is selectable and bookmarked, but is not a tagged PDF.
